from setuptools import setup

setup(name='gym_ct_cartpole',
      version='0.0.1',
      install_requires=['gym', 'numpy', 'scipy', 'pysindy']  # And any other dependencies foo needs
)
