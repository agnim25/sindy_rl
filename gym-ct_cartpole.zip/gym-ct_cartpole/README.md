To install the custom cart-pole gym environment, run the following command from this folder
> 'pip install -e .'